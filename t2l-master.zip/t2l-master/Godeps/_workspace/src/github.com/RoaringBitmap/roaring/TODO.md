### To do

  - Write performance benchmarks

