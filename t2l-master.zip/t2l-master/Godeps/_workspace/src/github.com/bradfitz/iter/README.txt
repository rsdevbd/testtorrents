See http://godoc.org/github.com/bradfitz/iter
